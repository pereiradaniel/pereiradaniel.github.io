/*****************************************************************************/
/* BeerCatalogue: Event Handlers */
/*****************************************************************************/
Template.BeerCatalogue.events({
});

/*****************************************************************************/
/* BeerCatalogue: Helpers */
/*****************************************************************************/
Template.BeerCatalogue.helpers({
	
});

/*****************************************************************************/
/* BeerCatalogue: Lifecycle Hooks */
/*****************************************************************************/
Template.BeerCatalogue.onCreated(function () {
});

Template.BeerCatalogue.onRendered(function () {
});

Template.BeerCatalogue.onDestroyed(function () {
});
