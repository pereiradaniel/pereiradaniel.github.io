/*****************************************************************************/
/* CheckoutBar: Event Handlers */
/*****************************************************************************/
Template.CheckoutBar.events({
});

/*****************************************************************************/
/* CheckoutBar: Helpers */
/*****************************************************************************/
Template.CheckoutBar.helpers({
});

/*****************************************************************************/
/* CheckoutBar: Lifecycle Hooks */
/*****************************************************************************/
Template.CheckoutBar.onCreated(function () {
});

Template.CheckoutBar.onRendered(function () {
});

Template.CheckoutBar.onDestroyed(function () {
});
