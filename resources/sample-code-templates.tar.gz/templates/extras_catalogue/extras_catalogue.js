/*****************************************************************************/
/* ExtrasCatalogue: Event Handlers */
/*****************************************************************************/
Template.ExtrasCatalogue.events({
});

/*****************************************************************************/
/* ExtrasCatalogue: Helpers */
/*****************************************************************************/
Template.ExtrasCatalogue.helpers({
});

/*****************************************************************************/
/* ExtrasCatalogue: Lifecycle Hooks */
/*****************************************************************************/
Template.ExtrasCatalogue.onCreated(function () {
});

Template.ExtrasCatalogue.onRendered(function () {
});

Template.ExtrasCatalogue.onDestroyed(function () {
});
