function toTitleCase(str) {
    return str.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
}

/*****************************************************************************/
/* PrimaryCatalogue: Event Handlers */
/*****************************************************************************/
Template.PrimaryCatalogue.events({
});

/*****************************************************************************/
/* PrimaryCatalogue: Helpers */
/*****************************************************************************/
Template.PrimaryCatalogue.helpers({
	'secondary_categories': function() {
		var type = Router.current().params.primary_category
		var results = ThirstyAlcoholCategories.findOne({ 'primary_category': toTitleCase(type) })
		if(results) {
			return results.secondary_categories
		}
	},
	'get_results': function(type) {
		var r = ThirstyAlcohol.find({ 'secondary_category': type }, {limit: 5}).fetch()
		var o = {}
		for (var i = 0; i < r.length; i++) {
			o['p'+ (i + 1)] = r[i]
		}
		return o
	},
	'primary_category': function() {
		var r = Router.current().params.primary_category
		//make sentence case here.
		return toTitleCase(r)
	},
	'return_primary_category_icon': function() {
		var type = Router.current().params.primary_category
			if (type == "beer") { return "icon ion-beer"; }
			else if (type == "wine") { return "icon ion-wineglass"; }
			else if (type == "liquor") { return "icon fa ion-android-bar"; }
			else if (type == "extras") { return "icon ion-coffee"; }
			else { return "" }
	}
});

/*****************************************************************************/
/* PrimaryCatalogue: Lifecycle Hooks */
/*****************************************************************************/
Template.PrimaryCatalogue.onCreated(function () {
});

Template.PrimaryCatalogue.onRendered(function () {
});

Template.PrimaryCatalogue.onDestroyed(function () {
});
