/*****************************************************************************/
/* ConfirmPaymentMethod: Event Handlers */
/*****************************************************************************/
Template.ConfirmPaymentMethod.events({
});

/*****************************************************************************/
/* ConfirmPaymentMethod: Helpers */
/*****************************************************************************/
Template.ConfirmPaymentMethod.helpers({
});

/*****************************************************************************/
/* ConfirmPaymentMethod: Lifecycle Hooks */
/*****************************************************************************/
Template.ConfirmPaymentMethod.onCreated(function () {
});

Template.ConfirmPaymentMethod.onRendered(function () {
});

Template.ConfirmPaymentMethod.onDestroyed(function () {
});
