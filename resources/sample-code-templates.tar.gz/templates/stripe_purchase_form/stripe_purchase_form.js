/*****************************************************************************/
/* StripePurchaseForm: Event Handlers */
/*****************************************************************************/
Template.StripePurchaseForm.events({
	'submit #stripe-purchase-form': function(event) {
			event.preventDefault()
			t = event.target
			$('#submit').prop('disabled', true)
			//add loading animation here
		
			var errors_empty = [];
			var errors_misc = 0;
			
			var card_number  = t.card_number.value
			var cvc    		 = t.cvc.value
			var expire_year  = t.expire_year.value
			var expire_month = t.expire_month.value
			
			if(card_number  === '') { errors_empty.push(' card number') }	
			if(cvc			=== '') { errors_empty.push(' cvc') }		
			if(expire_year  === 'placeholder') { errors_empty.push(' expiry year') }		
			if(expire_month === 'placeholder') { errors_empty.push(' expiry month') }		
			
			//errors
			//card number must be 16 digits long
			if(card_number.length !== 16) {
				Session.set('error_invalidCardNumberLength', 'Credit card numbers must be 16 digits long.')
				errors_misc += 1
			} else {
				Session.set('error_invalidCardNumberLength', '')
			}
			
			//cvc must be 3 or 4 digits
			if(cvc.length !== 3 && cvc.length !== 4) {
				Session.set('error_invalidCvcLength', 'CVC must be 3 or 4 digits long.')
				errors_misc += 1
			} else {
				Session.set('error_invalidCvcLength', '')
			}

			//expiry date must be in the future
			if( expire_year  !== 'placeholder' && expire_month !== 'placeholder' ) {
				var now = new Date()
				if(expire_month < now.getMonth() && expire_year <= (now.getFullYear() )) {
					Session.set('error_invalidExpiry', 'Expiry date must be in the future.')
					errors_misc += 1
				} else {
					Session.set('error_invalidExpiry', '')
				}
			}
			
			//Donation Amount
			/* SET THIS UP HOWEVER YOU WANT. The session variable is here for convenience */
			var charge_amount	= Session.get('purchase_amount') 
			
			//setup card data.
			var card_data = {}
			card_data.number 		= card_number
			card_data.cvc 			= cvc
			card_data.expire_year 	= expire_year
			card_data.expire_month 	= expire_month
			
			if(_.isEmpty(errors_empty) && errors_misc === 0) {
				//clear all previous error warnings
				Session.set('errors_empty', '')
				
				Stripe.card.createToken({
				    number: t.card_number.value,
				    cvc: t.cvc.value,
				    exp_month: t.expire_month.value,
				    exp_year: t.expire_year.value,
				}, function(status, response) {
				    stripeToken = response.id;
					$('#submit').prop('disabled', false)
				    Meteor.call('chargeCard', charge_amount, stripeToken, function(err, res) {
						if(err) {
							console.log('error processing card.')
							console.log(err)
						} else {
							console.log('card processed.')
							if(res) {
								console.log(res)
							} else {
								console.log('no response.')
							}
						}
						//re-enable
						$('#submit').prop('disabled', false)
				    });
				});
			} else {
				//append an '&' for stylistics
				if(errors_empty.length > 2) { 
					errors_empty[errors_empty.length - 1] = ' & ' + errors_empty[errors_empty.length - 1].toString()
					//log errors_empty
					Session.set('errors_empty', 'Please fill out: '+errors_empty+' to continue.')
				} else if(errors_empty.length === 2) {
					//log errors_empty
					Session.set('errors_empty', 'Please fill out: '+errors_empty[0]+' & '+errors_empty[1]+' to continue.')
				} else if (errors_empty.length === 1) {
					Session.set('errors_empty', 'Please fill out: ' + errors_empty[0])
				}
				
				//re-enable
				$('#submit').prop('disabled', false)
			}
		}
});

/*****************************************************************************/
/* StripePurchaseForm: Helpers */
/*****************************************************************************/
Template.StripePurchaseForm.helpers({
	error_invalidCardNumberLength: function() {
		return Session.get('error_invalidCardNumberLength')
	},
	error_invalidCvcLength: function() {
		return Session.get('error_invalidCvcLength')
	},
	error_invalidExpiry: function() {
		return Session.get('error_invalidExpiry')
	},
	errors_empty: function() {
		return Session.get('errors_empty')
	}
});

/*****************************************************************************/
/* StripePurchaseForm: Lifecycle Hooks */
/*****************************************************************************/
Template.StripePurchaseForm.onCreated(function () {
});

Template.StripePurchaseForm.onRendered(function () {
});

Template.StripePurchaseForm.onDestroyed(function () {
});