/*****************************************************************************/
/* UserProfilePersonalDetails: Event Handlers */
/*****************************************************************************/
Template.UserProfilePersonalDetails.events({
	'submit #user-personal-info': function(e) {
		e.preventDefault() 
		t = e.target

		var errors_empty = []
		var errors_misc = 0

		//fields
		var f = {}
		var keys = [ 
			'first_name', 'last_name', 'birth_date', 'default_address'
		]

		//populate f
		_.each(keys, function(key) {
			f[key] = t[key].value
		})

		//find empty values and report them.
		_.each(keys, function(key) {
			if(f[key] === '') {
				errors_empty.push(' '+key)
			} else if (f[key] === 'placeholder') {
				errors_empty.push(' '+key)
			}
			// any other conditions go here.
		})

		//ALL ERROR MISC CHECKING CAN GO HERE.

		//evaluate
		if(_.isEmpty(errors_empty) && !errors_misc) {
			Session.set('errors_empty', '')
			
			var user_profile = Meteor.user().profile
			//update the relevant properties
			_.extend(user_profile, f)
	
			//Make sure to choose the correct database.
			Meteor.users.update({ _id: Meteor.userId() }, {
				$set: {
					profile: user_profile
				}
			}, function(err, res) {
				if(!err) {
					_.each(keys, function(key) {
						t[key].value = ''
					})
				} else {
					console.log(err)
				}
			})
		} else {
			Session.set('errors_empty', 'Please fill in the following fields: '+ errors_empty)
		}
	},
});

/*****************************************************************************/
/* UserProfilePersonalDetails: Helpers */
/*****************************************************************************/
Template.UserProfilePersonalDetails.helpers({
	'errors_empty': function() {
		return Session.get('errors_empty')
	}
});

/*****************************************************************************/
/* UserProfilePersonalDetails: Lifecycle Hooks */
/*****************************************************************************/
Template.UserProfilePersonalDetails.onCreated(function () {
});

Template.UserProfilePersonalDetails.onRendered(function () {
	//load the Google autocomplete places.
	Meteor.startup(
		var predictiveSearch = function() { 
					var autocomplete = new google.maps.places.Autocomplete(document.getElementById('default_address'))
					var listener = autocomplete.addListener('place_changed', function() {
					var place = autocomplete.getPlace()
					var loc = geometry.location
					var lat = loc.lat()
					var lng = loc.lng()
					
					//check if Thirsty delivers to this location. 	
				})
		}
		
		function initMap() {
		  var map = new google.maps.Map(document.getElementById('default_address_map'), {
		    zoom: 5,
		    center: {lat: 24.886, lng: -70.268},
		    mapTypeId: google.maps.MapTypeId.TERRAIN
		  });
    	
		  // Define the LatLng coordinates for the polygon's path. Note that there's
		  // no need to specify the final coordinates to complete the polygon, because
		  // The Google Maps JavaScript API will automatically draw the closing side.
		  var triangleCoords = [
		    {lat: 25.774, lng: -80.190},
		    {lat: 18.466, lng: -66.118},
		    {lat: 32.321, lng: -64.757}
		  ];
    	
		  var bermudaTriangle = new google.maps.Polygon({
		    paths: triangleCoords,
		    strokeColor: '#FF0000',
		    strokeOpacity: 0.8,
		    strokeWeight: 3,
		    fillColor: '#FF0000',
		    fillOpacity: 0.35
		  });
		  bermudaTriangle.setMap(map);
		}
		
		initMap()
		predictiveSearch()
	)
});

Template.UserProfilePersonalDetails.onDestroyed(function () {
});
