/*****************************************************************************/
/* AccessBox: Event Handlers */
/*****************************************************************************/
Template.AccessBox.events({
	'click .toggleSignUp': function() {
		//if signup is off
		if(!Session.get('toggle_sign_up')) {
			//turn signup on, and trigger login off.
			Session.set('toggle_sign_up', true)
			Session.set('toggle_login', false)
			Session.set('toggle_forgot_password', false)
		}
	},
	'click .toggleLogin': function() {
		//if login is off
		if(!Session.get('toggle_login')) {
			//turn login on, and trigger sign up off. 
			Session.set('toggle_login', true)
			Session.set('toggle_sign_up', false)
			Session.set('toggle_forgot_password', false)
		}
	},
	
});

/*****************************************************************************/
/* AccessBox: Helpers */
/*****************************************************************************/
Template.AccessBox.helpers({
	'toggle_sign_up': function() {
		return Session.get('toggle_sign_up')
	},
	'toggle_login': function() {
		return Session.get('toggle_login')
	},
	'toggle_forgot_password': function() {
		return Session.get('toggle_forgot_password')
	}
});

/*****************************************************************************/
/* AccessBox: Lifecycle Hooks */
/*****************************************************************************/
Template.AccessBox.onCreated(function () {
});

Template.AccessBox.onRendered(function () {
	Session.set('toggle_forgot_password', false)
	Session.set('toggle_login', true)
	Session.set('toggle_sign_up', false)

});

Template.AccessBox.onDestroyed(function () {
});


