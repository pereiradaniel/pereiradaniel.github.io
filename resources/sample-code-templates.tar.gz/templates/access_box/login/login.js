/*****************************************************************************/
/* Login: Event Handlers */
/*****************************************************************************/
Template.Login.events({
	'submit .login': function(e) {
		e.preventDefault()
		var email = e.target.email.value
		var password = e.target.password.value
		
		Meteor.loginWithPassword(email, password, function(error) {
			if(error) {
				Session.set('errors_login', 'Invalid email or password. Please try again.')
			} else {
				Router.go('/')
			}
		})
	},
	'click #forgot-password': function() {
		//if login is off
		if(!Session.get('toggle_forgot_password')) {
			//turn login on, and trigger sign up off. 
			Session.set('toggle_forgot_password', true)
			Session.set('toggle_login', false)
			Session.set('toggle_sign_up', false)
		}
	},
});

/*****************************************************************************/
/* Login: Helpers */
/*****************************************************************************/
Template.Login.helpers({
	errors_login: function() {
		return Session.get('errors_login')
	}
});

/*****************************************************************************/
/* Login: Lifecycle Hooks */
/*****************************************************************************/
Template.Login.onCreated(function () {
});

Template.Login.onRendered(function () {
	$(document).ready(function(){
		$('[data-toggle="tooltip"]').tooltip();   
	});
});

Template.Login.onDestroyed(function () {
});
