/*****************************************************************************/
/* UserSetNewPassword: Event Handlers */
/*****************************************************************************/
Template.UserSetNewPassword.events({
	'submit #user-set-password': function(e) {
		e.preventDefault()
		t = e.target
		
		var errors_empty = []
		var errors_misc = 0

		//fields
		var f = {}
		var keys = [ 
			'current_password', 'new_password', 'confirm_new_password'
		]

		//populate f
		_.each(keys, function(key) {
			f[key] = t[key].value
		})

		//find empty values and report them.
		_.each(keys, function(key) {
			if(f[key] === '') {
				errors_empty.push(' '+key)
			} else if (f[key] === 'placeholder') {
				errors_empty.push(' '+key)
			}
			// any other conditions go here.
		})

		//ALL ERROR MISC CHECKING CAN GO HERE.

		//evaluate
		if(_.isEmpty(errors_empty) && !errors_misc) {
			Session.set('errors_empty', '')
	
			//Make sure to choose the correct database.
			Accounts.forgotPassword(f.current_password, f.new_password, function(err, res) {
				if(!err) {
					_.each(keys, function(key) {
						t[key].value = ''
					})
					Router.go('user_profile_security')
					//NOTE: Prompt user of success
				} else {
					Session.set('errors_set_password', err.reason)
				}
			})
		} else {
			Session.set('errors_empty', 'Please fill in the following fields: '+errors_empty)
		}
	}
});

/*****************************************************************************/
/* UserSetNewPassword: Helpers */
/*****************************************************************************/
Template.UserSetNewPassword.helpers({
	'errors_empty': function() {
		return Session.get('errors_empty')
	},
	'errors': function() {
		return Session.get('errors_set_password')
	}
});

/*****************************************************************************/
/* UserSetNewPassword: Lifecycle Hooks */
/*****************************************************************************/
Template.UserSetNewPassword.onCreated(function () {
});

Template.UserSetNewPassword.onRendered(function () {
});

Template.UserSetNewPassword.onDestroyed(function () {
});
