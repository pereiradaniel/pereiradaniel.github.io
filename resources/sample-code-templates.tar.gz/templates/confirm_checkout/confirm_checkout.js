/*****************************************************************************/
/* ConfirmCheckout: Event Handlers */
/*****************************************************************************/
Template.ConfirmCheckout.events({
});

/*****************************************************************************/
/* ConfirmCheckout: Helpers */
/*****************************************************************************/
Template.ConfirmCheckout.helpers({
});

/*****************************************************************************/
/* ConfirmCheckout: Lifecycle Hooks */
/*****************************************************************************/
Template.ConfirmCheckout.onCreated(function () {
});

Template.ConfirmCheckout.onRendered(function () {
});

Template.ConfirmCheckout.onDestroyed(function () {
});
