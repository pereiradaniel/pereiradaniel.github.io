/*****************************************************************************/
/* AdminDrivers: Event Handlers */
/*****************************************************************************/
Template.AdminDrivers.events({
});

/*****************************************************************************/
/* AdminDrivers: Helpers */
/*****************************************************************************/
Template.AdminDrivers.helpers({
});

/*****************************************************************************/
/* AdminDrivers: Lifecycle Hooks */
/*****************************************************************************/
Template.AdminDrivers.onCreated(function () {
});

Template.AdminDrivers.onRendered(function () {
});

Template.AdminDrivers.onDestroyed(function () {
});
