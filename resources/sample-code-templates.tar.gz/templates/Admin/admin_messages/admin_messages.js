/*****************************************************************************/
/* AdminMessages: Event Handlers */
/*****************************************************************************/
Template.AdminMessages.events({
});

/*****************************************************************************/
/* AdminMessages: Helpers */
/*****************************************************************************/
Template.AdminMessages.helpers({
});

/*****************************************************************************/
/* AdminMessages: Lifecycle Hooks */
/*****************************************************************************/
Template.AdminMessages.onCreated(function () {
});

Template.AdminMessages.onRendered(function () {
});

Template.AdminMessages.onDestroyed(function () {
});
