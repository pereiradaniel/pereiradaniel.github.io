/*****************************************************************************/
/* AdminLogin: Event Handlers */
/*****************************************************************************/
Template.AdminLogin.events({
	'submit .admin-login-form': function(e) {
		e.preventDefault()
		var email = e.target.email.value
		var password = e.target.password.value
		Meteor.loginWithPassword(email, password, function(error) {
			if(error) { console.log('error logging in') } else {
				Router.go('/admin/home')
			}
		})
	}
});

/*****************************************************************************/
/* AdminLogin: Helpers */
/*****************************************************************************/
Template.AdminLogin.helpers({
});

/*****************************************************************************/
/* AdminLogin: Lifecycle Hooks */
/*****************************************************************************/
Template.AdminLogin.onCreated(function () {
});

Template.AdminLogin.onRendered(function () {
});

Template.AdminLogin.onDestroyed(function () {
});
