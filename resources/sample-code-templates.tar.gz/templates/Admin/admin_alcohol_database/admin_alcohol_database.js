/*****************************************************************************/
/* AdminAlcoholDatabase: Event Handlers */
/*****************************************************************************/
Template.AdminAlcoholDatabase.events({
	'submit #add_alcohol_form': function(e) {
		e.preventDefault()
		t = e.target
		
		var errors_empty = []
		var errors_misc = 0;
		
		//fields
		var f = {}
		f.name = t.name.value 
		f.price = t.price.value 
		f.category = t.category.value 
		f.alcohol_percentage = t.alcohol_percentage.value 
		f.lcbo_id = t.lcbo_id.value 
		f.beer_store_id = t.beer_store_id.value 
		
		var keys = _.keys(f)
		
		//find empty values and report them.
		_.each(keys, function(key) {
			if(f[key] === '') {
				errors_empty.push(' '+key)
			} else if (f[key] === 'placeholder' && key === 'category') {
				errors_empty.push(' '+key)
			}
		})
		
		if(_.isEmpty(errors_empty) && !errors_misc) {
			//insert record
			// NOTICE: f._id can be used to come up with with better, more readable ID's.
			LCBO.insert(f, function(err, res) {
				if(!err) {
					t.name.value = ''
					t.price.value = ''
					t.category.value = ''
					t.alcohol_percentage.value = ''
					t.lcbo_id.value = ''
					t.beer_store_id.value = ''
				} else {
					console.log('There was an error inserting the Alcohol record into the collection.')
					console.log(err)
				}
			})
			
		} else {
			Session.set('errors_empty', 'Please fill in the following fields: '+ errors_empty)
		}
	}
});

/*****************************************************************************/
/* AdminAlcoholDatabase: Helpers */
/*****************************************************************************/
Template.AdminAlcoholDatabase.helpers({
	'errors_empty': function() {
		return Session.get('errors_empty')
	}
});

/*****************************************************************************/
/* AdminAlcoholDatabase: Lifecycle Hooks */
/*****************************************************************************/
Template.AdminAlcoholDatabase.onCreated(function () {
});

Template.AdminAlcoholDatabase.onRendered(function () {
});

Template.AdminAlcoholDatabase.onDestroyed(function () {
});
