/*****************************************************************************/
/* AdminOrders: Event Handlers */
/*****************************************************************************/
Template.AdminOrders.events({
});

/*****************************************************************************/
/* AdminOrders: Helpers */
/*****************************************************************************/
Template.AdminOrders.helpers({
});

/*****************************************************************************/
/* AdminOrders: Lifecycle Hooks */
/*****************************************************************************/
Template.AdminOrders.onCreated(function () {
});

Template.AdminOrders.onRendered(function () {
});

Template.AdminOrders.onDestroyed(function () {
});
