/*****************************************************************************/
/* AdminInsertDriver: Event Handlers */
/*****************************************************************************/
Template.AdminInsertDriver.events({
	'submit #insert-driver-form': function(e) {
		e.preventDefault()
		t = e.target
		
		var errors_empty = []
		var errors_misc = 0;
		
		//fields
		var f = {}
		var keys = [ 
			'first_name', 
			'last_name', 
			'date_of_birth', 
			'licence_number', 
			'address', 
			'postal_code', 
			'telephone', 
			'thirsty_id', 
			'email'
		]
		
		_.each(keys, function(key) {
			f[key] = t[key].value
		})
		
		//find empty values and report them.
		_.each(keys, function(key) {
			if(f[key] === '') {
				errors_empty.push(' '+key)
			} else if (f[key] === 'placeholder' && key === 'category') {
				errors_empty.push(' '+key)
			}
		})
		
		if(_.isEmpty(errors_empty) && !errors_misc) {
			Session.set('errors_empty', '')
			Meteor.call('insert_new_driver', f)
			LCBO.insert(f, function(err, res) {
				if(!err) {
					_.each(keys, function(key) {
						t[key].value = ''
					})
				} else {
					console.log('There was an error inserting the Alcohol record into the collection.')
					console.log(err)
				}
			})
		} else {
			Session.set('errors_empty', 'Please fill in the following fields: '+ errors_empty)
		}
	}
});

/*****************************************************************************/
/* AdminInsertDriver: Helpers */
/*****************************************************************************/
Template.AdminInsertDriver.helpers({
	'errors_empty': function() {
		return Session.get('errors_empty')
	}
});

/*****************************************************************************/
/* AdminInsertDriver: Lifecycle Hooks */
/*****************************************************************************/
Template.AdminInsertDriver.onCreated(function () {
});

Template.AdminInsertDriver.onRendered(function () {
});

Template.AdminInsertDriver.onDestroyed(function () {
});
