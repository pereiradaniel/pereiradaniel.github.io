/*****************************************************************************/
/* AdminAlcoholDatabaseDisplay: Event Handlers */
/*****************************************************************************/
Template.AdminAlcoholDatabaseDisplay.events({
});

/*****************************************************************************/
/* AdminAlcoholDatabaseDisplay: Helpers */
/*****************************************************************************/
Template.AdminAlcoholDatabaseDisplay.helpers({
	'total_alcohol_category_count': function(category) {
		return Alcohol.find({category: category}).count()
	},
	total_alcohol_count: function() {
		return Alcohol.find().count()
	}
});

/*****************************************************************************/
/* AdminAlcoholDatabaseDisplay: Lifecycle Hooks */
/*****************************************************************************/
Template.AdminAlcoholDatabaseDisplay.onCreated(function () {
});

Template.AdminAlcoholDatabaseDisplay.onRendered(function () {
});

Template.AdminAlcoholDatabaseDisplay.onDestroyed(function () {
});
