Template.MasterLayout.helpers({
});

Template.MasterLayout.events({
	'click #sign-out': function() {
		Meteor.logout()
		Router.go('/')
	},
	'click #menu-button': function(event) {
	    // $('div.main-content').toggleClass("mask");
	    $('.mask').fadeIn(400);
		},
	'click div.data-ion-menu-close': function(event) {
    $('.mask').fadeOut(400);
    // $('div.main-content').toggleClass("mask");
	}
});

Template.MasterLayout.onRendered(function () {
	$(document).ready( function() {
		$('div.main-content').toggleClass("mask");
    $('.mask').fadeOut(400);
	});
});