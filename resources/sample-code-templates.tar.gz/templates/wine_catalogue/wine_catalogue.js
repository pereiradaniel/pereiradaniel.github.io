/*****************************************************************************/
/* WineCatalogue: Event Handlers */
/*****************************************************************************/
Template.WineCatalogue.events({
});

/*****************************************************************************/
/* WineCatalogue: Helpers */
/*****************************************************************************/
Template.WineCatalogue.helpers({
});

/*****************************************************************************/
/* WineCatalogue: Lifecycle Hooks */
/*****************************************************************************/
Template.WineCatalogue.onCreated(function () {
});

Template.WineCatalogue.onRendered(function () {
});

Template.WineCatalogue.onDestroyed(function () {
});
