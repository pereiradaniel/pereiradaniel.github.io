/*****************************************************************************/
/* SearchFilterBar: Event Handlers */
/*****************************************************************************/
Template.SearchFilterBar.events({
});

/*****************************************************************************/
/* SearchFilterBar: Helpers */
/*****************************************************************************/
Template.SearchFilterBar.helpers({
});

/*****************************************************************************/
/* SearchFilterBar: Lifecycle Hooks */
/*****************************************************************************/
Template.SearchFilterBar.onCreated(function () {
});

Template.SearchFilterBar.onRendered(function () {
});

Template.SearchFilterBar.onDestroyed(function () {
});
