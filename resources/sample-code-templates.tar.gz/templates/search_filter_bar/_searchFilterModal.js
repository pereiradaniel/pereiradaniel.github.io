/*****************************************************************************/
/* SearchFilterBar: Event Handlers */
/*****************************************************************************/
Template._searchFilterModal.events({
});

/*****************************************************************************/
/* SearchFilterBar: Helpers */
/*****************************************************************************/
Template._searchFilterModal.helpers({
});

/*****************************************************************************/
/* SearchFilterBar: Lifecycle Hooks */
/*****************************************************************************/
Template._searchFilterModal.onCreated(function () {
});

Template._searchFilterModal.onRendered(function () {
	$(document).ready(function() {

    $(".dropdown dt a").click(function() {
      $(".dropdown dd ul").toggle();
			// $('#list').scrollTop($('#list').height())
		});
                
    $(".dropdown dd ul li a").click(function() {
      var text = $(this).html();
      $(".dropdown dt a span").html(text);
      $(".dropdown dd ul").hide();
      // $("#result").html("Selected value is: " + getSelectedValue("sample"));
    });
                
    function getSelectedValue(id) {
   	 return $("#" + id).find("dt a span.value").html();
    }

    $(document).bind('click', function(e) {
      var $clicked = $(e.target);
      if (! $clicked.parents().hasClass("dropdown"))
        $(".dropdown dd ul").hide();
    });
	});
});

Template._searchFilterModal.onDestroyed(function () {
});
