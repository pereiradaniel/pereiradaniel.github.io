/*****************************************************************************/
/* CatalogueIndex: Event Handlers */
/*****************************************************************************/
Template.CatalogueIndex.events({
});

/*****************************************************************************/
/* CatalogueIndex: Helpers */
/*****************************************************************************/
Template.CatalogueIndex.helpers({
});

/*****************************************************************************/
/* CatalogueIndex: Lifecycle Hooks */
/*****************************************************************************/
Template.CatalogueIndex.onCreated(function () {
});

Template.CatalogueIndex.onRendered(function () {
	$(document).ready(function(){
		// debugger
	});
	$("#size").load(function(){
		resizeDiv();
	});

	window.onresize = function(event) {
		resizeDiv();
	}

	function resizeDiv() {
		vpw = $(".content").width();
		vph = $(".content").height();
		padding = parseInt($(".row").css("padding"));
		searchBarHeight = $(".search-bar").height() + padding * 3;
		// $(".catalogue-index").css({"height": (vph - searchBarHeight) + "px"});
		$(".col").css({"height": (vph - searchBarHeight) / 3 + "px"});
		$("img").css({"height": "100%"});
		$("img").css({"max-width": "100%"});
		resizeMiddleColumnWidth();
	}
	function resizeMiddleColumnWidth() {
		var wideImageWidth = $("#size").css("width");
		$(".middle").css({"width": wideImageWidth});
	}
});

Template.CatalogueIndex.onDestroyed(function () {
});
