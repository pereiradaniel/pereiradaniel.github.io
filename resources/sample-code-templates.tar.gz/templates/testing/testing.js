/*****************************************************************************/
/* Testing: Event Handlers */
/*****************************************************************************/
Template.Testing.events({
	'change #search_product': function() {
		var val = $('#search_product').val()
		Session.set('search_product', val)
	},
	'submit #alcohol_organizer': function(e) {
		e.preventDefault()
		t = e.target
		debugger
		check_completed 	= t.check_completed.checked
		lcbo_unique 		= t.lcbo_unique.checked
		beer_store_unique 	= t.beer_store_unique.checked
		pair 				= t.pair.checked

		lcbo_selection = parseInt(t.lcbo_product.value)
		beer_store_selection = parseInt(t.beer_store_product.value)

		Session.set('lcbo_record', LCBO.find({ product_no: lcbo_selection }).fetch()[0]) 
		Session.set('beer_store_record', BeerStoreAlcohol.find({ product_id: beer_store_selection }).fetch()[0])
		
		var number_selected = lcbo_unique + beer_store_unique + pair
		//we should have only ONE that's selected.
		if(number_selected === 1) {
			var lcbo_record = Session.get('beer_store_record')
			var beer_store_record = Session.get('lcbo_record')
			
			if(lcbo_unique) {
				ThirstyAlcohol.insert({
					name: lcbo_record.name,
					lcbo_record: lcbo_record
				}, function(err, res) {
					if(!err) {
						var lcbo_id = lcbo_record._id
						if(check_completed) {
							Alcohol.update({ _id: lcbo_id }, {$set: {checked_completed: true}})
						}
						
						AlcoholOrganizerLogs.insert({
							name: lcbo_record.name,
							createdAt: new Date(),
							lcbo_id: lcbo_id
						})
					}
				})
			} 
		
			if(beer_store_unique) {
				ThirstyAlcohol.insert({
					name: beer_store_record.name,
					beer_store_record: beer_store_record
				}, function(err, res) {
					if(!err) {
						var beer_store_id = beer_store_record._id
						if(check_completed) {
							BeerStoreAlcohol.update({ _id: beer_store_id }, {$set: {checked_completed: true}})	
						}
						
						AlcoholOrganizerLogs.insert({
							name: beer_store_record.name,
							createdAt: new Date(),
							beer_store_id: beer_store_id
						})
					}
				})
			}
			
			console.log('lcbo record from outside pair')
			console.log(lcbo_record)
			
			if(pair) {
				ThirstyAlcohol.insert({
					name: lcbo_record.name,
					lcbo_record: lcbo_record,
					beer_store_record: beer_store_record
				}, function(err, res) {
					if(!err) {
						var lcbo_id = lcbo_record._id
						var beer_store_id = beer_store_record._id
						console.log('lcbo record from inside pair')
						console.log(lcbo_record)
						
						if(check_completed) {
							LCBO.update({ _id: lcbo_id }, {$set: {checked_completed: true} }, function(err, res) {
								if(err) {
									console.log('error from pair updating alcohol'); console.log(err) 
								} else {
									console.log('success from pair updating alcohol'); console.log(res)
								} 
							})
							BeerStoreAlcohol.update({ _id: beer_store_id }, {$set: {checked_completed: true}}, function(err, res) {
								if(err) {
									console.log('error from pair updating alcohol'); console.log(err) 
								} else {
									console.log('success from pair updating alcohol'); console.log(res)
								} 
							})
						}	
						
						AlcoholOrganizerLogs.insert({
							createdAt: new Date(),
							name: lcbo_record.name,
							lcbo_id: lcbo_id,
							beer_store_id: beer_store_id
						})
					}
				})
			}
			
			// if(check_completed) {
// 				RefreshProducts()
// 			}
			
			t.check_completed.checked = false
			t.lcbo_unique.checked = false
			t.beer_store_unique.checked = false
			t.pair.checked = false
			
		}
	}
});

/*****************************************************************************/
/* Testing: Helpers */
/*****************************************************************************/
Template.Testing.helpers({
	'beer_store_products': function(name) {
		return BeerStoreAlcohol.find({ 
			name: name,
			checked_completed: {$ne: true}
		})
	},
	'lcbo_products': function(name) {
		var regex = new RegExp(name)
		return LCBO.find({ 
			name: { $regex: regex }, 
			checked_completed: {$ne: true} 
		})
	},
	'searchable_products': function() {
		return Session.get('searchable_products')
	},
	'search_product': function() {
		return Session.get('search_product')
	}
});

/*****************************************************************************/
/* Testing: Lifecycle Hooks */
/*****************************************************************************/
Template.Testing.onCreated(function () {
});

Template.Testing.onRendered(function () {
		//init
		Session.set('search_product', 'ZZZZZZ')
	 	Session.set('searchable_products', [])
	
		//LCBO Products
		//844
		var lcbo_products_dump = LCBO.find({}).fetch()
		var all_names = []
		_.each(lcbo_products_dump, function(product) {
			all_names.push(product.name)
		})
		var lcbo_products = _.uniq(all_names)
		Session.set('lcbo_products', lcbo_products)
		
		//Beer Store Products
		//480
		var beer_store_products_dump = BeerStoreAlcohol.find({}).fetch()
		var all_names = []
		_.each(beer_store_products_dump, function(product) {
			all_names.push(product.name)
		})
		var beer_store_products = _.uniq(all_names)
		Session.set('beer_store_products', beer_store_products)
		
		//set an array for products you're going to use to compare db records with. 
		RefreshProducts = function() {
			Session.set('searchable_products', [])
			var p = Session.get('beer_store_products')
			_.each(p, function(name) {
				var regex = new RegExp(name)
				var condition = LCBO.find({ name: {$regex: regex} })
				if(condition.count()) {
					var n = Session.get('searchable_products')
					n.push(name)
					Session.set('searchable_products', n)
				}
			})
		}
		
		RefreshProducts()
});

Template.Testing.onDestroyed(function () {

});
