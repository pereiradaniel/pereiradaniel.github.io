/*****************************************************************************/
/* UserCreditCards: Event Handlers */
/*****************************************************************************/
Template.UserCreditCards.events({
});

/*****************************************************************************/
/* UserCreditCards: Helpers */
/*****************************************************************************/
Template.UserCreditCards.helpers({
});

/*****************************************************************************/
/* UserCreditCards: Lifecycle Hooks */
/*****************************************************************************/
Template.UserCreditCards.onCreated(function () {
});

Template.UserCreditCards.onRendered(function () {
});

Template.UserCreditCards.onDestroyed(function () {
});
