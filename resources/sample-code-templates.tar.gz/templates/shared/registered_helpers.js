Template.registerHelper('alcohol_categories', function() {
	//Update this list whenever you add new categories of alcohol.
	//This should be update concurrently with the alcohol Schema. 
	return ['beer', 'vodka', 'whiskey', 'rum', 'gin', 'brandy', 'tequila', 'cognacArmagnac', 'liqueur', 'eauDeVie', 'shochuSoju']
})

Template.registerHelper('userProfile', function() {
	if(Meteor.user()) {
		return Meteor.user().profile
	}
})