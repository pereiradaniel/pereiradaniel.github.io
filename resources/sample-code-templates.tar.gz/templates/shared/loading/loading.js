Template.Loading.onRendered(function () {
})

Template.Loading.helpers({
	'p5': function() {
		function randomIntFromInterval(min,max) {
		    return Math.floor(Math.random()*(max-min+1)+min);
		}
		
		var loading = function(k) {
			x = 0
		
			k.setup = function() {
				var canvas = k.createCanvas(500, 500)
				canvas.parent('loading-container');
				k.background(255)
				k.stroke(0)
				k.strokeWeight(10)
			}
		
			k.draw = function() {
				if(x < 180) {
					k.clear()
					x += 1
				} else {
					x = 0 
					var r = randomIntFromInterval(0, 255)
					var g = randomIntFromInterval(0, 255)
					var b = randomIntFromInterval(0, 255)
					k.background(255)
					k.stroke(r, g, b)
				}
				k.line(30, k.cos(x)*x, 75, k.sin(x)*x)
			}
		}
	
		var it = new p5(loading)
	}
})