/*****************************************************************************/
/* SecondaryCatalogue: Event Handlers */
/*****************************************************************************/
Template.SecondaryCatalogue.events({
});

/*****************************************************************************/
/* SecondaryCatalogue: Helpers */
/*****************************************************************************/
Template.SecondaryCatalogue.helpers({
});

/*****************************************************************************/
/* SecondaryCatalogue: Lifecycle Hooks */
/*****************************************************************************/
Template.SecondaryCatalogue.onCreated(function () {
});

Template.SecondaryCatalogue.onRendered(function () {
});

Template.SecondaryCatalogue.onDestroyed(function () {
});
