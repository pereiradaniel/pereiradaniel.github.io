/*****************************************************************************/
/* CartListItem: Event Handlers */
/*****************************************************************************/
Template.CartListItem.events({
});

/*****************************************************************************/
/* CartListItem: Helpers */
/*****************************************************************************/
Template.CartListItem.helpers({
});

/*****************************************************************************/
/* CartListItem: Lifecycle Hooks */
/*****************************************************************************/
Template.CartListItem.onCreated(function () {
});

Template.CartListItem.onRendered(function () {
});

Template.CartListItem.onDestroyed(function () {
});
