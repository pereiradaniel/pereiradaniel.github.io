/*****************************************************************************/
/* SlideMenuRight: Event Handlers */
/*****************************************************************************/
Template.SlideMenuRight.events({
	'click #signOut': function() {
		Meteor.logout()
	}
});

/*****************************************************************************/
/* SlideMenuRight: Helpers */
/*****************************************************************************/
Template.SlideMenuRight.helpers({
});

/*****************************************************************************/
/* SlideMenuRight: Lifecycle Hooks */
/*****************************************************************************/
Template.SlideMenuRight.onCreated(function () {
});

Template.SlideMenuRight.onRendered(function () {
});

Template.SlideMenuRight.onDestroyed(function () {
});
