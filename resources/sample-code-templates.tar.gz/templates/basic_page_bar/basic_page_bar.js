/*****************************************************************************/
/* BasicPageBar: Event Handlers */
/*****************************************************************************/
Template.BasicPageBar.events({
});

/*****************************************************************************/
/* BasicPageBar: Helpers */
/*****************************************************************************/
Template.BasicPageBar.helpers({
});

/*****************************************************************************/
/* BasicPageBar: Lifecycle Hooks */
/*****************************************************************************/
Template.BasicPageBar.onCreated(function () {
});

Template.BasicPageBar.onRendered(function () {
});

Template.BasicPageBar.onDestroyed(function () {
});
