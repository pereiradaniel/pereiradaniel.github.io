/*****************************************************************************/
/* ProductShow: Event Handlers */
/*****************************************************************************/
Template.ProductShow.events({
});

/*****************************************************************************/
/* ProductShow: Helpers */
/*****************************************************************************/
Template.ProductShow.helpers({
	'product': function() {
		var product_id = Router.current().params.product_id
		var r = ThirstyAlcohol.findOne({ _id: product_id })
		if(r) {
			return r
		}
	},
	'get_prices': function(product_id) {
		var p = ThirstyAlcohol.findOne({ _id: product_id })
		var lcbo_products = p.lcbo
		var beer_store_products = p.beer_store
		
		//only lcbo for now.
		var results = []
		_.each(lcbo_products, function(product) {
			var a = {}
			a.price 			= (product.price_in_cents)/100
			a.package 			= product.package
			//we use the native LCBO id as a value because that stays the same regardless of our db. 
			a.id 				= product.id
			results.push(a)
		})
		
		return results
	}
});

/*****************************************************************************/
/* ProductShow: Lifecycle Hooks */
/*****************************************************************************/
Template.ProductShow.onCreated(function () {
});

Template.ProductShow.onRendered(function () {
});

Template.ProductShow.onDestroyed(function () {
});
