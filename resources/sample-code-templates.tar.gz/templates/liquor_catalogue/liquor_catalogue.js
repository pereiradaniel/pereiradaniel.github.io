/*****************************************************************************/
/* LiquorCatalogue: Event Handlers */
/*****************************************************************************/
Template.LiquorCatalogue.events({
});

/*****************************************************************************/
/* LiquorCatalogue: Helpers */
/*****************************************************************************/
Template.LiquorCatalogue.helpers({
});

/*****************************************************************************/
/* LiquorCatalogue: Lifecycle Hooks */
/*****************************************************************************/
Template.LiquorCatalogue.onCreated(function () {
});

Template.LiquorCatalogue.onRendered(function () {
});

Template.LiquorCatalogue.onDestroyed(function () {
});
