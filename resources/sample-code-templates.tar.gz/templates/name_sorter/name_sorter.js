function toTitleCase(str) {
    return str.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
}

/*****************************************************************************/
/* NameSorter: Event Handlers */
/*****************************************************************************/
Template.NameSorter.events({
	'click #newRecordBasedOnBeerStore': function() {
		var beer_inputs = $('.beer_store, input')
		var checked = []
		_.each(beer_inputs, function(input) {
			if(input.checked) {
				checked.push(input)
			}
		})
		var input = checked[0]
		if(checked.length > 1) {
			window.alert('Only one check box allowed.')
		} else if(checked.length === 0) {
			window.alert('Atleast one check box is needed.')
		} else {
			var beer_store_product_id = input.attributes.id.value
			var beer_store_product = BeerStoreAlcohol.findOne({ _id: beer_store_product_id})
			
			//Add a new record
			ThirstyAlcohol.insert({ 
				name: $(input).val(),
				beer_store: [
					{
						product: beer_store_product,
						stores_available_in: [],
						updated_on: new Date(),
					}
				],
				lcbo: [],
				createdAt: new Date()
			}, function(err, res) {
				if(err) {
					window.alert('Nope.')
					console.log('NOPE!')
				} else {
					$(input)[0].checked = false
					
					BeerStoreAlcohol.update({ _id: beer_store_product_id }, {
						$set: {
							checked: true
						}
					})
				}
			})
		}
	},
	'click #newRecordBasedOnLCBO': function() {
		var lcbo_inputs = $('.lcbo, input')
		var checked = []
		_.each(lcbo_inputs, function(input) {
			if(input.checked) {
				checked.push(input)
			}
		})
		var input = checked[0]
		if(checked.length > 1) {
			window.alert('Only one check box allowed.')
		} else if(checked.length === 0) {
			window.alert('Atleast one check box is needed.')
		} else {
			var lcbo_product_id = input.attributes.id.value
			var lcbo_product = LCBO.findOne({ _id: lcbo_product_id})
			
			ThirstyAlcohol.insert({ 
				name: $(input).val(),
				beer_store: [],
				lcbo: [
					{
						product: lcbo_product,
						stores_available_in: [],
						updated_on: new Date(),
					}
				],
				createdAt: new Date()
			}, function(err, res) {
				if(err) {
					window.alert('Nope.')
					console.log('NOPE!')
				} else {
					$(input)[0].checked = false
					
					LCBO.update({ _id: lcbo_product_id }, {
						$set: {
							checked: true
						}
					})
				}
			})
		}
	},
	'click #addBeerStoreRecordToCurrentSelection': function() {
		var thirsty_product_id = $('#thirstyProducts').val()
		var beer_inputs = $('.beer_store, input')
		var checked = []
		_.each(beer_inputs, function(input) {
			if(input.checked) {
				checked.push(input)
			}
		})
		var input = checked[0]
		if(checked.length === 0) {
			window.alert('Atleast one check box is needed.')
		} else {
			var beer_store_product_id = input.attributes.id.value
			var beer_store_product = BeerStoreAlcohol.findOne({ _id: beer_store_product_id})
			  
			ThirstyAlcohol.update({ _id: thirsty_product_id }, {
				$push: {
					beer_store: beer_store_product
				}
			}, function(err, res) {
				if(err) {
					window.alert('Nope.')
					console.log('NOPE!')
				} else {
					$(input)[0].checked = false
					
					BeerStoreAlcohol.update({ _id: beer_store_product_id }, {
						$set: {
							checked: true
						}
					})
				}
			})
		}	
	},
	'click #addLCBORecordToCurrentSelection': function() {
		var thirsty_product_id = $('#thirstyProducts').val()
		var lcbo_inputs = $('.beer_store, input')
		var checked = []
		_.each(lcbo_inputs, function(input) {
			if(input.checked) {
				checked.push(input)
			}
		})
		var input = checked[0]
		if(checked.length === 0) {
			window.alert('Atleast one check box is needed.')
		} else {
			var lcbo_product_id = input.attributes.id.value
			var lcbo_product = LCBOAlcohol.findOne({ _id: lcbo_product_id})
			  
			ThirstyAlcohol.update({ _id: thirsty_product_id }, {
				$push: {
					beer_store: lcbo_product
				}
			}, function(err, res) {
				if(err) {
					window.alert('Nope.')
					console.log('NOPE!')
				} else {
					$(input)[0].checked = false
					
					LCBO.update({ _id: lcbo_product_id }, {
						$set: {
							checked: true
						}
					})
				}
			})
		}	
	},
	'click #autosortBasedOnLCBO': function() {
		var products = LCBO.find({ checked: {$ne: true}, 'primary_category': 'Beer'}).fetch()
		_.each(products, function(product) {
			//look for an existing record
			var product_name = product.name
			var existingName = ThirstyAlcohol.find({ name: product_name })
			if(existingName.count()) {
				var _id = existingName.fetch()[0]._id
				ThirstyAlcohol.update({ _id: _id }, {
					$push: {
						lcbo: {
							product: product,
							stores_available_in: [],
							updated_on: new Date(),
						}
					}
				}, function(err, res) {
					if(!err) {
						LCBO.update({ _id: product._id }, {
							$set: {
								checked: true
							}
						})
					}
				})
			} else {
				//if it's new. 
				ThirstyAlcohol.insert({ 
					name: product_name,
					primary_category: product.primary_category,
					secondary_category: product.secondary_category,
					image_thumb_url: product.image_thumb_url,
					description: product.description,
					origin: product.origin,
					beer_store: [],
					lcbo: [
						{
							product: product,
							stores_available_in: [],
							updated_on: new Date(),
						}
					],
					createdAt: new Date()
				}, function(err, res) {
					if(!err) {
						LCBO.update({ _id: product._id }, {
							$set: {
								checked: true
							}
						})
					}
				})
			}
		})
	},
	'click #setProductStores': function() {
		//sets up the stores that have this product available and appends ThirstyAlcohol document.
		Meteor.call('set_product_stores')
	},
	'keyup #beerStoreSearch': function() {
		var input = $('#beerStoreSearch').val()
		if(input) {
			Session.set('beer_store_search', toTitleCase(input))
		} else {
			Session.set('beer_store_search', ' ')
		}
	},
	'keyup #LCBOSearch': function() {
		var input = $('#LCBOSearch').val()
		Session.set('lcbo_search', toTitleCase(input))
		if(input) {
			Session.set('lcbo_search', toTitleCase(input))
		} else {
			Session.set('lcbo_search', ' ')
		}
	},
	'change #thirstyProducts': function() {
		var selection_id = $('#thirstyProducts').val()
		Session.set('selected_thirsty_product', selection_id)
	}
});

/*****************************************************************************/
/* NameSorter: Helpers */
/*****************************************************************************/
Template.NameSorter.helpers({
	'beer_store_products': function() {
		var input = Session.get('beer_store_search')
		if(input) {
			return BeerStoreAlcohol.find({
				name: {$regex: new RegExp(input)},
				checked: {$ne: true}
			},  {sort: {name: 1}})
		}
	},
	'lcbo_products': function() {
		var input = Session.get('lcbo_search')
		if(input) {
			return LCBO.find({
				name: {$regex: new RegExp(input)},
				checked: {$ne: true}
			},  {sort: {name: 1}})
		}
	},
	'thirsty_products': function() {
		return ThirstyAlcohol.find({}, {sort: {name: 1}})
	},
	'selected_thirsty_product': function() {
		var _id = Session.get('selected_thirsty_product')
		return ThirstyAlcohol.find({ _id: _id })
	}
});

/*****************************************************************************/
/* NameSorter: Lifecycle Hooks */
/*****************************************************************************/
Template.NameSorter.onCreated(function () {
});

Template.NameSorter.onRendered(function () {
});

Template.NameSorter.onDestroyed(function () {
});
