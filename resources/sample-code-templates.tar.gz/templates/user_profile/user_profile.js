/*****************************************************************************/
/* UserProfile: Event Handlers */
/*****************************************************************************/
Template.UserProfile.events({
});

/*****************************************************************************/
/* UserProfile: Helpers */
/*****************************************************************************/
Template.UserProfile.helpers({
});

/*****************************************************************************/
/* UserProfile: Lifecycle Hooks */
/*****************************************************************************/
Template.UserProfile.onCreated(function () {
});

Template.UserProfile.onRendered(function () {
});

Template.UserProfile.onDestroyed(function () {
});
