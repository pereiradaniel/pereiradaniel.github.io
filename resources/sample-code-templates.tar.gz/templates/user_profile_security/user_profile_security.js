/*****************************************************************************/
/* UserProfileSecurity: Event Handlers */
/*****************************************************************************/
Template.UserProfileSecurity.events({
});

/*****************************************************************************/
/* UserProfileSecurity: Helpers */
/*****************************************************************************/
Template.UserProfileSecurity.helpers({
});

/*****************************************************************************/
/* UserProfileSecurity: Lifecycle Hooks */
/*****************************************************************************/
Template.UserProfileSecurity.onCreated(function () {
});

Template.UserProfileSecurity.onRendered(function () {
});

Template.UserProfileSecurity.onDestroyed(function () {
});
