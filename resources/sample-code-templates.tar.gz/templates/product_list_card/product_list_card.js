/*****************************************************************************/
/* ProductListCard: Event Handlers */
/*****************************************************************************/
Template.ProductListCard.events({
});

/*****************************************************************************/
/* ProductListCard: Helpers */
/*****************************************************************************/
Template.ProductListCard.helpers({
});

/*****************************************************************************/
/* ProductListCard: Lifecycle Hooks */
/*****************************************************************************/
Template.ProductListCard.onCreated(function () {
});

Template.ProductListCard.onRendered(function () {
});

Template.ProductListCard.onDestroyed(function () {
});
