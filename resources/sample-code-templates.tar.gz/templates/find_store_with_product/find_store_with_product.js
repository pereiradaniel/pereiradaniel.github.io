/*****************************************************************************/
/* FindStoreWithProduct: Event Handlers */
/*****************************************************************************/
Template.FindStoreWithProduct.events({
});

/*****************************************************************************/
/* FindStoreWithProduct: Helpers */
/*****************************************************************************/
Template.FindStoreWithProduct.helpers({
	exampleMapOptions: function() {
	  if (GoogleMaps.loaded()) {
	    // Map initialization options
	    return {
	      center: new google.maps.LatLng(-37.8136, 144.9631),
	      zoom: 8
	    };
	  }
	}
});

/*****************************************************************************/
/* FindStoreWithProduct: Lifecycle Hooks */
/*****************************************************************************/
Template.FindStoreWithProduct.onCreated(function () {
});

Template.FindStoreWithProduct.onRendered(function () {
	GoogleMaps.load();
	
    GoogleMaps.ready('exampleMap', function(map) {
       // Add a marker to the map once it's ready
       var marker = new google.maps.Marker({
         position: map.options.center,
         map: map.instance
       });
     });
});

Template.FindStoreWithProduct.onDestroyed(function () {
});
