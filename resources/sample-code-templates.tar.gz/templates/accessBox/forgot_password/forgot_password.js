/*****************************************************************************/
/* ForgotPassword: Event Handlers */
/*****************************************************************************/
Template.ForgotPassword.events({
	'submit #forgot-password-form': function(e) {
		e.preventDefault()
		var t = e.target
		var email = t.email.value
		
		Accounts.forgotPassword({
			email: email
		}, function(error) {
			if(error) {
				Session.set('forgot_password_message', "Sorry, we couldn't send your password reset email. Please contact Thirsty at support@thirsty.deliver. Thank you for your understanding.")
			} else {
				Session.set('forgot_password_message', 'An email has been sent to '+email)
				t.email.value = ''
			}
		})
	}
});

/*****************************************************************************/
/* ForgotPassword: Helpers */
/*****************************************************************************/
Template.ForgotPassword.helpers({
	'forgot_password_message': function() {
		return Session.get('forgot_password_message')
	}
});

/*****************************************************************************/
/* ForgotPassword: Lifecycle Hooks */
/*****************************************************************************/
Template.ForgotPassword.onCreated(function () {
});

Template.ForgotPassword.onRendered(function () {
	Session.set('forgot_password_message', '')
	$(document).ready(function(){
		$('[data-toggle="tooltip"]').tooltip();   
	});
});

Template.ForgotPassword.onDestroyed(function () {
});
