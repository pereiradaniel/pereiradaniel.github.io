/*****************************************************************************/
/* SignUp: Event Handlers */
/*****************************************************************************/
Template.Register.events({
	'submit .register-form': function(e) {
		e.preventDefault()
		t = e.target

		//check for values that are empty 
		var errors_empty = []
		if(t.first_name.value === '') 		{ errors_empty.push(' first name') 			}
		if(t.last_name.value === '') 		{ errors_empty.push(' last name') 			}
		if(t.email.value === '') 			{ errors_empty.push(' email') 				}
		if(t.password.value === '') 		{ errors_empty.push(' password') 			}
		if(t.date_of_birth.value === '') 	{ errors_empty.push(' date of birth') 		}
		if(t.terms.checked === false) 		{ errors_empty.push(' terms & agreements') 	}	

		//username setup
		var firstname 	= t.first_name.value.toLowerCase()
		var lastname 	= t.last_name.value.toLowerCase()
		var username;
		if(Session.get('usernameDefaultUnavailable')) {
			username = $('#usernameSearch').val()
		} else {
			username = firstname + '.' + lastname;
		}
		
		//all other errors 
		//errors_misc is a count
		//actual errors get logged through changing session variables.
		var errors_misc = 0;

		//First name invalid
		var first_name = $('#first_name').val()
		var firstNameReg = new RegExp('[^A-Za-z]', 'gi')
		var firstNameTest = firstNameReg.test(first_name)

		//if test fails
		if(firstNameTest) {
			Session.set('error_FirstNameInvalid', 'Please enter a valid first name.')
			errors_misc += 1
		} else {
			Session.set('error_FirstNameInvalid', null)

		}

		//Last name invalid
		var last_name = $('#last_name').val()
		var lastNameReg = new RegExp('[^A-Za-z-]', 'gi')
		var lastNameTest = lastNameReg.test(last_name)

		//if test fails
		if(lastNameTest) {
			Session.set('error_LastNameInvalid', 'Please enter a valid last name.')
			errors_misc += 1
		} else {
			Session.set('error_LastNameInvalid', null)
		}


		//Email Invalid
		var email = $('#email').val()
		var emailReg = SimpleSchema.RegEx.Email
		var emailTest = emailReg.test(email)

		//if test is failed
		if(!emailTest) {
			Session.set('error_EmailInvalid', 'Please enter a valid email address.')
			errors_misc += 1
		} else {
			Session.set('error_EmailInvalid', null)
		}

		//Email Exists
		var existingEmails = Meteor.users.find({ emails: {$elemMatch: {address: email} }}).count()
		if(existingEmails > 0) {
			//we've added another dynamic warning called warning_email. It's triggered by
			//the keyup event found later on in the page. 
			errors_misc += 1
		}

		//Password too short
		if(t.password.value.length < 8) {
			Session.set('error_PasswordInvalidLength', 'Password must be at least 8 characters long.')
			errors_misc += 1
		}
		
		//Date of Birth
		var now = new Date()
		var today = now.toLocaleDateString()
		var date_of_birth = t.date_of_birth.value
		var d = date_of_birth.split('-')
		date_of_birth = d[1] + '/' + d[2] + '/' +d[0]
		
		//Handy function. 
		var calculateAge = function(birthDate, otherDate) {
		    birthDate = new Date(birthDate);
		    otherDate = new Date(otherDate);

		    var years = (otherDate.getFullYear() - birthDate.getFullYear());

		    if (otherDate.getMonth() < birthDate.getMonth() || 
		        otherDate.getMonth() == birthDate.getMonth() && otherDate.getDate() < birthDate.getDate()) {
		        years--;
		    }
			return years
		}
   
   	 	var age = calculateAge(date_of_birth, today)
		if(age < 0) {
			//As the user is not longer too young, we must clear the error.
			Session.set('error_tooYoung', '')
			Session.set('error_mustBeInThePast', 'You must set a birth date in the past.')
			errors_misc += 1
		} else if(age < 19) {
			//As the date is no longer in the future, we must clear the error.
			Session.set('error_mustBeInThePast', '')
			Session.set('error_tooYoung', 'You must be atleast 19 years old to order alcohol through Thirsty.')
			errors_misc += 1
		} else {
			Session.set('error_tooYoung', '')
			Session.set('error_mustBeInThePast', '')
		}
		
		//add checks
		//if no errors_empty
		if(_.isEmpty(errors_empty) && errors_misc === 0) {
			//create user and clear error messages
			Session.set('errors_empty', '')
			Session.set('errors_createUserFunction', '')

			var args = {}
			args.email 			= t.email.value
			args.password 	= t.password.value

			args.profile = {}
			var p = args.profile
			p.first_name = t.first_name.value
			p.last_name = t.last_name.value
			p.terms = t.terms.checked
			p.date_of_birth = date_of_birth
			p.address = {
				'address': '',
				'province': '',
				'country': 'Canada'
			}
			p.phone_number = ''

			Meteor.call('create_user', args, function(error) {
				if(error) {
					Session.set('errors_createUserFunction', error.reason)
				} else {
					t.email.value = ''
					t.password.value = ''
					t.first_name.value = ''
					t.last_name.value = ''
					t.terms.checked = false
					
					Meteor.loginWithPassword(args.email, args.password)
					Router.go('/')
				}
			})			
		} else {
			//append an '&' for stylistics
			if(errors_empty.length > 2) { 
				errors_empty[errors_empty.length - 1] = ' & ' + errors_empty[errors_empty.length - 1].toString()
				//log errors_empty
				Session.set('errors_empty', 'Please fill out: '+errors_empty+' to continue.')
			} else if(errors_empty.length === 2) {
				//log errors_empty
				Session.set('errors_empty', 'Please fill out: '+errors_empty[0]+' & '+errors_empty[1]+' to continue.')
			} else if (errors_empty.length === 1) {
				Session.set('errors_empty', 'Please fill out: ' + errors_empty[0])
			}
		}
	},
	'keyup #email': function() {
		var email = $('#email').val()
		var existingEmails = Meteor.users.find({ emails: {$elemMatch: {address: email} }}).count()
		var warnings = Session.get('warning_email')
		if(existingEmails > 0) {
			Session.set('warning_email', 'A user already exists with that user.')
		} else {
			Session.set('warning_email', null)
		}
	},
  'click [data-action="showAlert"]': function(event, template) {
    IonPopup.alert({
      title: 'Terms and Agreements',
      template: 'The terms and agreements are as follows: Ispum lorem gluteus maximus.',
      okText: 'Got It.'
    });
  }
});

/*****************************************************************************/
/* Register: Helpers */
/*****************************************************************************/
Template.Register.helpers({
	'errors_empty': function() {
		return Session.get('errors_empty')
	},
	'errors_createUserFunction': function() {
		return Session.get('errors_createUserFunction')
	},
	'error_EmailInvalid': function() {
		return Session.get('error_EmailInvalid')
	},
	'error_EmailExists': function() {
		return Session.get('error_EmailExists')
	},
	'error_PasswordInvalidLength': function() {
		return Session.get('error_PasswordInvalidLength')
	},
	'error_FirstNameInvalid': function() {
		return Session.get('error_FirstNameInvalid')
	},
	'error_LastNameInvalid': function() {
		return Session.get('error_LastNameInvalid')
	},
	'error_mustBeInThePast': function() {
		return Session.get('error_mustBeInThePast')
	},
	'error_tooYoung': function() {
		return Session.get('error_tooYoung')
	},
	'warning_email': function() {
		return Session.get('warning_email')
	}
});

/*****************************************************************************/
/* Register: Lifecycle Hooks */
/*****************************************************************************/
Template.Register.onCreated(function () {
});

Template.Register.onRendered(function () {
});

Template.Register.onDestroyed(function () {
});
