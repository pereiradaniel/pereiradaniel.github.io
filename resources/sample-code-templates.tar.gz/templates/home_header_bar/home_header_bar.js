/*****************************************************************************/
/* HomeHeaderBar: Event Handlers */
/*****************************************************************************/
Template.HomeHeaderBar.events({
});

/*****************************************************************************/
/* HomeHeaderBar: Helpers */
/*****************************************************************************/
Template.HomeHeaderBar.helpers({
});

/*****************************************************************************/
/* HomeHeaderBar: Lifecycle Hooks */
/*****************************************************************************/
Template.HomeHeaderBar.onCreated(function () {
});

Template.HomeHeaderBar.onRendered(function () {
});

Template.HomeHeaderBar.onDestroyed(function () {
});
