/*****************************************************************************/
/* SuccessfullyPurchased: Event Handlers */
/*****************************************************************************/
Template.SuccessfullyPurchased.events({
});

/*****************************************************************************/
/* SuccessfullyPurchased: Helpers */
/*****************************************************************************/
Template.SuccessfullyPurchased.helpers({
});

/*****************************************************************************/
/* SuccessfullyPurchased: Lifecycle Hooks */
/*****************************************************************************/
Template.SuccessfullyPurchased.onCreated(function () {
});

Template.SuccessfullyPurchased.onRendered(function () {
});

Template.SuccessfullyPurchased.onDestroyed(function () {
});
